from lib.test.evaluation.environment import EnvSettings

def local_env_settings():
    settings = EnvSettings()

    # Set your local paths here.

    settings.coesot_path = '/mnt/data/yjj/SpikeET/data/COESOT'
    settings.fe108_path = '/mnt/data/yjj/SpikeET/data/FE108'
    settings.got10k_path = '/mnt/data/yjj/SpikeET/data/got10k'
    settings.lasot_path = '/mnt/data/yjj/SpikeET/data/lasot'
    settings.network_path = '/mnt/data/yjj/SpikeET/output/test/networks'    # Where tracking networks are stored.
    settings.prj_dir = '/mnt/data/yjj/SpikeET'
    settings.result_plot_path = '/mnt/data/yjj/SpikeET/output/test/result_plots'
    settings.results_path = '/mnt/data/yjj/SpikeET/output/test/tracking_results'    # Where to store tracking results
    settings.save_dir = '/mnt/data/yjj/SpikeET/output'
    settings.segmentation_path = '/mnt/data/yjj/SpikeET/output/test/segmentation_results'
    settings.trackingnet_path = '/mnt/data/yjj/SpikeET/data/trackingnet'
    settings.visevent_path = '/home/work/yjj/VisEvent_half'

    return settings

