# test visevent
python tracking/test.py spikefet spikeet_visevent --dataset visevent --threads 4 --num_gpus 1 --ckpt \
./output/checkpoints/train/spikefet/spikeet_visevent/SpikeET_VisEvent.pth
