# test fe108
python tracking/test.py spikefet spikeet_fe108 --dataset fe108 --threads 4 --num_gpus 2 --ckpt \
./output/checkpoints/train/spikefet/spikeet_fe108/SpikeET_FE108.pth
